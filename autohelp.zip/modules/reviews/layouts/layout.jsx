import style from './style.module.scss'

export const ReviewsSection = () => {
    return (
        <div className={style.container}>
            <h1>Скоро здесь будут отзывы.</h1>
        </div>
    )
}