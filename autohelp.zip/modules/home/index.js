export {
    MainSection,
    WhyUs,
    OurServices,
    LoadCapacity,
    WhereWeWork,
    TireService,
    OurWork,
    Contacts
} from './layouts'