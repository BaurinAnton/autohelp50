export { MainSection } from "./MainSection"
export { WhyUs } from "./WhyUs"
export { OurServices } from "./OurServices"
export { LoadCapacity } from "./LoadСapacity"
export { WhereWeWork } from "./WhereWeWork"
export { TireService } from "./TireService"
export { OurWork } from "./OurWork"
export { Contacts } from "./Contacts"


