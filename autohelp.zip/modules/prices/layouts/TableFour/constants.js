export const TABLE = {
    TITLE: 'Шиномонтаж спецтехники',
    TABLE_ONE: [
        { CONTENT: 'Услуга', id: 1 },
        { CONTENT: 'Цена', id: 2 },
        { CONTENT: 'Демонтаж 1 сторона', id: 3 },
        { CONTENT: '350', id: 4 },
        { CONTENT: 'Монтаж 1 сторона', id: 5 },
        { CONTENT: '350', id: 6 },
        { CONTENT: 'Снятие, установка', id: 7 },
        { CONTENT: '400', id: 8 },
        { CONTENT: 'Установка камеры', id: 9 },
        { CONTENT: '200', id: 10 },
        { CONTENT: 'Ремонт покрышки', id: 11 },
        { CONTENT: '450, без материала', id: 12 },
        { CONTENT: 'Ремонт камер', id: 13 },
        { CONTENT: '250', id: 14 },
    ]
}