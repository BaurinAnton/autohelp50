export const TABLE_FOUR = {
    TITLE: [
        { title: 'Грузовой шиномонтаж' },
    ],
    COLUMN_ONE: [
        { title: 'Наименование' },
        { content: 'Демонтаж 1 сторона' },
        { content: 'Монтаж 1 сторона' },
        { content: 'Снятие, установка' },
        { content: 'Установка камеры' },
        { content: 'Ремонт покрышки' },
        { content: 'Ремонт камер' }
    ],
    COLUMN_TO: [
        { title: 'Цена' },
        { content: '350' },
        { content: '350' },
        { content: '400' },
        { content: '200' },
        { content: '450, без материала' },
        { content: '250' },
    ],
}

