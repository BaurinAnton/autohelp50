export const THE_COST_OF_TIRE_REPAIR = {
    TITLE: 'Стоимость шиномонтажа.',
    TITLE_MOBILE: [
        {TITLE: 'Стоимость'},
        {TITLE: 'шиномонтажа.'}
    ],
    DEPARTURE: [
        { TITLE: 'Выездной шиномонтаж:' },
        { CONTENT: 'Выезд стоит ' },
        { CONTENT: '3000 рублей до 20 км' }
    ],
}