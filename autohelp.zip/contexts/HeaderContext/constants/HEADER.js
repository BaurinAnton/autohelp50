export const HEADER = {
    NAV_LINKS: [
        { id: 1, name: 'Почему мы?', HREF: '/' },
        { id: 2, name: 'Услуги', HREF: '/' },
        { id: 3, name: 'Шиномонтаж', HREF: '/' },
        { id: 4, name: 'Работы', HREF: '/' },
        { id: 5, name: 'Цены', HREF: '/' },
        { id: 6, name: 'Отзывы', HREF: '/' },
        { id: 7, name: 'Контакты', HREF: '/' }
    ]
}