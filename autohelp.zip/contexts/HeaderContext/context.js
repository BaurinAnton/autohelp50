import { createContext } from 'react'

import { HEADER } from './constants'

export const HEADER_CONTEXT = { HEADER }
export const HeaderContext = createContext()