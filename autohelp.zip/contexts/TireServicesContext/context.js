import { createContext } from 'react'

import { WHYOURTIRESERVICE } from './constants'

export const WHYOURTIRESERVICE_CONSTANT = {
    WHYOURTIRESERVICE
}

export const WhyOurTireServiceContext = createContext()