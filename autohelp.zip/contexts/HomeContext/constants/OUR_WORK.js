export const OUR_WORK = {
    TITLE: 'Наши работы.'
}