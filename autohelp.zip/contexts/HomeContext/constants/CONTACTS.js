export const CONTACTS = {
    TITLE: 'Контакты.',
    CONTENT: [
        [
            { TEL: '+7 (925) 049 99-62 — ' },
            { CONTENT: 'Кашира' }
        ],
        [
            { TEL: '+7 (919) 082 68-95 — ' },
            { CONTENT: 'Ступино' }
        ],
        [
            { CONTENT: 'telegram' },
            { CONTENT: 'whatsapp' }
        ]
    ]
}