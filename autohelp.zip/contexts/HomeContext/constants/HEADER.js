export const HEADER = {
    NAV_LINKS: [
        { id: 1, name: 'Почему мы?', HREF: '/#whyUs' },
        { id: 2, name: 'Услуги', HREF: '/#ourServices' },
        { id: 3, name: 'Шиномонтаж', HREF: '/tireServices' },
        { id: 4, name: 'Работы', HREF: '/#ourWork' },
        { id: 5, name: 'Цены', HREF: '/prices' },
        { id: 6, name: 'Отзывы', HREF: '/reviews' },
        { id: 7, name: 'Контакты', HREF: '/#contacts' }
    ]
}