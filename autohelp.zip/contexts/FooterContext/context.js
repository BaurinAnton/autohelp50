import { createContext } from 'react'

import { FOOTER } from './constants'

export const FOOTER_CONSTANT = {
    FOOTER
}

export const FooterContext = createContext()