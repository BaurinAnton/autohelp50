export { SwiperDesktop } from './SwiperDesktop'
export { SwiperTablet } from './SwiperTablet'
export { SwiperMobile } from './SwiperMobile'