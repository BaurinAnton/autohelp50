exports.id = 40;
exports.ids = [40];
exports.modules = {

/***/ 9040:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SB": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.SB),
/* harmony export */   "hi": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.hi),
/* harmony export */   "N3": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.N3),
/* harmony export */   "LB": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.LB),
/* harmony export */   "x_": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.x_),
/* harmony export */   "HQ": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.HQ),
/* harmony export */   "qs": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.qs),
/* harmony export */   "zB": () => (/* reexport safe */ _layouts__WEBPACK_IMPORTED_MODULE_0__.zB)
/* harmony export */ });
/* harmony import */ var _layouts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2573);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts__WEBPACK_IMPORTED_MODULE_0__]);
_layouts__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 6445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "z": () => (/* reexport */ Contacts)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/home/layouts/Contacts/style.module.scss
var style_module = __webpack_require__(6977);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/Contacts/layout.jsx






const Contacts = () => {
  const {
    CONTACTS: {
      TITLE,
      CONTENT
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    id: "contacts",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).container,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/MainPage/whyUs/line.svg",
              alt: "line"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
              children: TITLE
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "img/MainPage/contacts/numberEight.svg",
            alt: "eight"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "tel:89250499962",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[0][0].TEL
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[0][1].CONTENT
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "tel:89190826895",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[1][0].TEL
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[1][1].CONTENT
              })]
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://t.me/autohelp50",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/contacts/telegram.svg",
                alt: "telegram"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: CONTENT[2][0].CONTENT
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://wa.me/qr/JFTGGKKYMDGEN1",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/contacts/whatsapp.svg",
                alt: "whatsapp"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: CONTENT[2][1].CONTENT
              })]
            })
          })]
        })]
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/Contacts/index.js


/***/ }),

/***/ 9904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "L": () => (/* reexport */ LoadCapacity)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/home/layouts/LoadСapacity/style.module.scss
var style_module = __webpack_require__(7080);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/LoadСapacity/layout.jsx





const LoadCapacity = () => {
  const {
    LOAD_CAPACITY: {
      TITLE,
      CONTENT
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (style_module_default()).container,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).wrapper,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).row,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/img/MainPage/whyUs/line.svg",
                alt: "line"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                children: TITLE
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).column,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/loadCapacity/number.svg",
              alt: "number"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).row,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[0][0].CONTENT
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[0][1].CONTENT
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[1][0].CONTENT
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: CONTENT[1][1].CONTENT
              }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/loadCapacity/zvezda.svg",
                alt: "zvezda"
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[2][0].CONTENT
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).column,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/loadCapacity/auto.jpg",
              alt: "auto"
            })
          })]
        })]
      })
    })
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/LoadСapacity/index.js


/***/ }),

/***/ 8810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "S": () => (/* reexport */ MainSection)
});

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./modules/header/index.js + 15 modules
var header = __webpack_require__(480);
;// CONCATENATED MODULE: ./modules/shared.js

// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/home/layouts/MainSection/style.module.scss
var style_module = __webpack_require__(4699);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/MainSection/layout.jsx







const MainSection = () => {
  const {
    MAIN_SECTION: {
      CONTENT
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: (style_module_default()).section,
    children: [/*#__PURE__*/jsx_runtime_.jsx(header/* Header */.h, {
      headerOtherPage: false
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).container,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            children: CONTENT[0][0].H1
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: CONTENT[0][1].H2
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "tel:89250499962",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: (style_module_default()).button,
              children: 'Заказать'
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/img/MainPage/mainSection/one.svg",
            alt: "number"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: CONTENT[1][0].TITLE
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: (style_module_default()).border,
            children: CONTENT[1][1].CONTENT
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: CONTENT[2][0].TITLE
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: (style_module_default()).border,
            children: CONTENT[2][1].CONTENT
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: CONTENT[3][0].TITLE
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            children: CONTENT[3][1].CONTENT
          })]
        })]
      })]
    })]
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/MainSection/index.js


/***/ }),

/***/ 6192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "N": () => (/* reexport */ OurServices)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/home/layouts/OurServices/style.module.scss
var style_module = __webpack_require__(4537);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/OurServices/layout.jsx





const OurServices = () => {
  const {
    OUR_SERVICES: {
      TITLE,
      CONTENT
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    id: "ourServices",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (style_module_default()).container,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).wrapper,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).row,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/MainPage/whyUs/line.svg",
              alt: "line"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              children: TITLE
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).column,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/ourServices/number.svg",
              alt: "number"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).row,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).column,
            children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
              children: CONTENT[0][0].TITLE
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/ourServices/auto.png",
                alt: "auto"
              }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
                children: CONTENT[1][0].TITLE
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/ourServices/tractor.png",
                alt: "tractor"
              }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
                children: CONTENT[1][1].TITLE
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/ourServices/skating.png",
                alt: "skating"
              }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
                children: CONTENT[1][2].TITLE
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/ourServices/trailer.png",
                alt: "trailer"
              }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
                children: CONTENT[1][3].TITLE
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/ourServices/bike.png",
                alt: "bike"
              }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
                children: CONTENT[1][4].TITLE
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/ourServices/other.png",
                alt: "other"
              }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
                children: CONTENT[1][5].TITLE
              })]
            })]
          })]
        })]
      })
    })
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/OurServices/index.js


/***/ }),

/***/ 9450:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* reexport safe */ _layout__WEBPACK_IMPORTED_MODULE_0__.q)
/* harmony export */ });
/* harmony import */ var _layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9313);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout__WEBPACK_IMPORTED_MODULE_0__]);
_layout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 9313:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ OurWork)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1393);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7009);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2488);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ui__WEBPACK_IMPORTED_MODULE_1__]);
_ui__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const imagesSwiper = [{
  id: 1,
  src: '/img/MainPage/ourWork/photoOne.jpg',
  alt: 'auto'
}, {
  id: 2,
  src: '/img/MainPage/ourWork/photoTo.jpg',
  alt: 'auto'
}, {
  id: 3,
  src: '/img/MainPage/ourWork/protoThree.jpg',
  alt: 'auto'
}, {
  id: 4,
  src: '/img/MainPage/ourWork/photoFour.jpg',
  alt: 'auto'
}, {
  id: 5,
  src: '/img/MainPage/ourWork/photoFive.jpg',
  alt: 'auto'
}];
const OurWork = () => {
  const {
    OUR_WORK: {
      TITLE
    }
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_2__/* .HomeContext */ .Q8);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("section", {
    id: "ourWork",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().container),
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().row),
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().column),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
            src: "/img/MainPage/whyUs/line.svg",
            alt: "line"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
            children: TITLE
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
          className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().column),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
            src: "img/MainPage/ourWork/numberSeven.svg",
            alt: "number"
          })
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().row),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_ui__WEBPACK_IMPORTED_MODULE_1__/* .SwiperUI */ .U, {
          imagesSwiper: imagesSwiper
        })
      })]
    })
  });
};
});

/***/ }),

/***/ 1892:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* reexport */ TireService)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./modules/home/layouts/TireService/style.module.scss
var style_module = __webpack_require__(3683);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/TireService/layout.jsx






const TireService = ({
  imageNumber
}) => {
  const {
    TIRE_SERVICES: {
      TITLE,
      CONTENT
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).container,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/img/MainPage/whyUs/line.svg",
            alt: "line"
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: TITLE
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: imageNumber,
            alt: "number"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/tireService/wheelCar.png",
                alt: "car"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                children: CONTENT[0].TITLE
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/tireService/carText.svg",
              alt: "car"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/tireService/wheelCargoCar.png",
                alt: "car"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                children: CONTENT[1].TITLE
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/tireService/cargoCarText.svg",
              alt: "car"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                  media: "(min-width: 578px)",
                  srcSet: "img/MainPage/tireService/tools.png"
                }), /*#__PURE__*/jsx_runtime_.jsx("source", {
                  media: "(max-width: 577px)",
                  srcSet: "img/MainPage/tireService/toolsMobile.png"
                }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "img/MainPage/tireService/tools.png",
                  alt: "tools"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                children: CONTENT[2].TITLE
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/tireService/tools.svg",
              alt: "tools"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/MainPage/tireService/wheels.png",
                alt: "wheels"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).box,
              children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                children: CONTENT[3].TITLE
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/tireService/wheel\u0421argo\u0421arBU.png",
              alt: "cargo car"
            }), /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "img/MainPage/tireService/BuText.svg",
              className: (style_module_default()).backgroundBu,
              alt: "text"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (style_module_default()).column,
          children: CONTENT[3].TITLE
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/prices",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: (style_module_default()).link,
          children: CONTENT[4].CONTENT
        })
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/TireService/index.js


/***/ }),

/***/ 3414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "x": () => (/* reexport */ WhereWeWork)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/home/layouts/WhereWeWork/style.module.scss
var style_module = __webpack_require__(5291);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/WhereWeWork/layout.jsx





const WhereWeWork = () => {
  const {
    WHERE_WE_WORK: {
      TITLE,
      CONTENT
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).container,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/img/MainPage/whyUs/line.svg",
            alt: "line"
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: TITLE
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/img/MainPage/whereWeWork/number.svg",
            alt: "number"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
              children: CONTENT[0][0].TITLE
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
              children: CONTENT[1][0].TITLE
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][1].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][2].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][3].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][4].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][5].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][6].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[1][7].CONTENT
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
              children: CONTENT[2][0].TITLE
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[2][1].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[2][2].CONTENT
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                media: "(min-width: 993px)",
                srcSet: "/img/MainPage/whereWeWork/cardOne.jpg"
              }), /*#__PURE__*/jsx_runtime_.jsx("source", {
                media: "(max-width: 992px)",
                srcSet: "/img/MainPage/whereWeWork/cardOneTablet.jpg"
              }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/img/MainPage/whereWeWork/cardOne.jpg",
                alt: "card one"
              })]
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
              children: CONTENT[0][1].TITLE
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
              children: CONTENT[3][0].TITLE
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[3][1].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[3][2].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[3][3].CONTENT
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[3][4].CONTENT
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).items,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
              children: CONTENT[4][0].TITLE
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: CONTENT[4][1].CONTENT
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).items,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                media: "(min-width: 993px)",
                srcSet: "/img/MainPage/whereWeWork/cardTo.jpg"
              }), /*#__PURE__*/jsx_runtime_.jsx("source", {
                media: "(max-width: 992px)",
                srcSet: "/img/MainPage/whereWeWork/cardToTablet.jpg"
              }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/img/MainPage/whereWeWork/cardOne.jpg",
                alt: "card One"
              })]
            })
          })]
        })]
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/WhereWeWork/index.js


/***/ }),

/***/ 3573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* reexport */ WhyUs)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./modules/home/layouts/WhyUs/style.module.scss
var style_module = __webpack_require__(1904);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/home/layouts/WhyUs/layout.jsx





const WhyUs = () => {
  const {
    MAIN_SECTION,
    WHY_US
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    id: "whyUs",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).wrapper,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).container,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: MAIN_SECTION.CONTENT[1][0].TITLE
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: (style_module_default()).border,
            children: MAIN_SECTION.CONTENT[1][1].CONTENT
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: MAIN_SECTION.CONTENT[2][0].TITLE
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: (style_module_default()).border,
            children: MAIN_SECTION.CONTENT[2][1].CONTENT
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).column,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: MAIN_SECTION.CONTENT[3][0].TITLE
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            children: MAIN_SECTION.CONTENT[3][1].CONTENT
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).container,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).row,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/MainPage/whyUs/line.svg",
              alt: "line"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              children: WHY_US.TITLE
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).column,
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/MainPage/whyUs/number.svg",
              alt: "line"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).row,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                children: WHY_US.CONTENT[0][0].TITLE
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[0][1].CONTENT
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[0][2].CONTENT
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[0][3].CONTENT
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[0][4].CONTENT
                })]
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/img/MainPage/whyUs/tros.png",
                alt: "tros"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                  srcSet: "/img/MainPage/whyUs/evacuate.svg",
                  media: "(min-width: 993px)"
                }), /*#__PURE__*/jsx_runtime_.jsx("source", {
                  srcSet: "/img/MainPage/whyUs/evacuateTablet.svg",
                  media: "(max-width: 992px)"
                }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/img/MainPage/whyUs/evacuate.svg",
                  alt: "evacuate"
                })]
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (style_module_default()).column,
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: WHY_US.CONTENT[1][0].CONTENT
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                children: WHY_US.CONTENT[2][0].CONTENT
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: WHY_US.CONTENT[2][1].CONTENT
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/img/MainPage/whyUs/exclamationMark.svg",
                alt: "exclamationMark"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).column,
            children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/MainPage/whyUs/shinomontajTablet.png",
              className: (style_module_default()).backShinomontaj,
              alt: "shinomontaj"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (style_module_default()).items,
              children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                children: WHY_US.CONTENT[3][0].TITLE
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[3][1].CONTENT
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[3][2].CONTENT
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[3][3].CONTENT
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: '—'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: WHY_US.CONTENT[3][4].CONTENT
                })]
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                  srcSet: "/img/MainPage/whyUs/wheels.png",
                  media: "(min-width: 993px)"
                }), /*#__PURE__*/jsx_runtime_.jsx("source", {
                  srcSet: "/img/MainPage/whyUs/wheelsTablet.png",
                  media: "(max-width: 992px)"
                }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/img/MainPage/whyUs/wheels.png",
                  alt: "wheels"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (style_module_default()).items,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/img/MainPage/whyUs/shinomontaj.svg",
                alt: "shinomontaj"
              })
            })]
          })]
        })]
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/home/layouts/WhyUs/index.js


/***/ }),

/***/ 2573:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SB": () => (/* reexport safe */ _MainSection__WEBPACK_IMPORTED_MODULE_0__.S),
/* harmony export */   "hi": () => (/* reexport safe */ _WhyUs__WEBPACK_IMPORTED_MODULE_1__.h),
/* harmony export */   "N3": () => (/* reexport safe */ _OurServices__WEBPACK_IMPORTED_MODULE_2__.N),
/* harmony export */   "LB": () => (/* reexport safe */ _Load_apacity__WEBPACK_IMPORTED_MODULE_3__.L),
/* harmony export */   "x_": () => (/* reexport safe */ _WhereWeWork__WEBPACK_IMPORTED_MODULE_4__.x),
/* harmony export */   "HQ": () => (/* reexport safe */ _TireService__WEBPACK_IMPORTED_MODULE_5__.H),
/* harmony export */   "qs": () => (/* reexport safe */ _OurWork__WEBPACK_IMPORTED_MODULE_6__.q),
/* harmony export */   "zB": () => (/* reexport safe */ _Contacts__WEBPACK_IMPORTED_MODULE_7__.z)
/* harmony export */ });
/* harmony import */ var _MainSection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8810);
/* harmony import */ var _WhyUs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3573);
/* harmony import */ var _OurServices__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6192);
/* harmony import */ var _Load_apacity__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9904);
/* harmony import */ var _WhereWeWork__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3414);
/* harmony import */ var _TireService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1892);
/* harmony import */ var _OurWork__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9450);
/* harmony import */ var _Contacts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6445);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_OurWork__WEBPACK_IMPORTED_MODULE_6__]);
_OurWork__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








});

/***/ }),

/***/ 8157:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ SwiperUI)
/* harmony export */ });
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8178);
/* harmony import */ var _hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4589);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_0__]);
_components__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const SwiperUI = ({
  imagesSwiper
}) => {
  let windowSize = (0,_hook__WEBPACK_IMPORTED_MODULE_1__/* .useWindowSize */ .i)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: windowSize.width >= 992 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components__WEBPACK_IMPORTED_MODULE_0__/* .SwiperDesktop */ .M2, {
      imagesSwiper: imagesSwiper
    }) : windowSize.width >= 578 && windowSize.width < 992 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components__WEBPACK_IMPORTED_MODULE_0__/* .SwiperTablet */ .vT, {
      imagesSwiper: imagesSwiper
    }) : windowSize.width < 577 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components__WEBPACK_IMPORTED_MODULE_0__/* .SwiperMobile */ .rw, {
      imagesSwiper: imagesSwiper
    }) : ''
  });
};
});

/***/ }),

/***/ 762:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ SwiperDesktop)
/* harmony export */ });
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2156);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4074);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5254);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_0__, swiper__WEBPACK_IMPORTED_MODULE_1__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_0__, swiper__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







swiper__WEBPACK_IMPORTED_MODULE_1__.default.use([swiper__WEBPACK_IMPORTED_MODULE_1__.Scrollbar, swiper__WEBPACK_IMPORTED_MODULE_1__.Autoplay]);
const SwiperDesktop = ({
  imagesSwiper
}) => {
  const images = imagesSwiper.map(list => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_0__.SwiperSlide, {
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().swiperSlide),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
      src: list.src,
      alt: list.alt
    })
  }, list.id));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_0__.Swiper, {
    spaceBetween: 50,
    slidesPerView: 3,
    scrollbar: {
      draggable: true
    },
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().Swiper),
    autoplay: {
      delay: 2000
    },
    disableOnInteraction: true,
    loop: true,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
      children: images
    })
  });
};
});

/***/ }),

/***/ 2859:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* reexport safe */ _component__WEBPACK_IMPORTED_MODULE_0__.M)
/* harmony export */ });
/* harmony import */ var _component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(762);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component__WEBPACK_IMPORTED_MODULE_0__]);
_component__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 2682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* reexport safe */ _layout__WEBPACK_IMPORTED_MODULE_0__.r)
/* harmony export */ });
/* harmony import */ var _layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8832);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout__WEBPACK_IMPORTED_MODULE_0__]);
_layout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 8832:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ SwiperMobile)
/* harmony export */ });
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2156);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4074);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9445);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_0__, swiper__WEBPACK_IMPORTED_MODULE_1__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_0__, swiper__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







swiper__WEBPACK_IMPORTED_MODULE_1__.default.use([swiper__WEBPACK_IMPORTED_MODULE_1__.Scrollbar, swiper__WEBPACK_IMPORTED_MODULE_1__.Autoplay]);
const SwiperMobile = ({
  imagesSwiper
}) => {
  const images = imagesSwiper.map(list => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_0__.SwiperSlide, {
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().swiperSlide),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
      src: list.src,
      alt: list.alt
    })
  }, list.id));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_0__.Swiper, {
    spaceBetween: 30,
    slidesPerView: 1.3,
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().Swiper),
    loop: true,
    autoplay: {
      delay: 2000
    },
    disableOnInteraction: true,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
      children: images
    })
  });
};
});

/***/ }),

/***/ 7755:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* reexport safe */ _layout__WEBPACK_IMPORTED_MODULE_0__.v)
/* harmony export */ });
/* harmony import */ var _layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(235);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout__WEBPACK_IMPORTED_MODULE_0__]);
_layout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ SwiperTablet)
/* harmony export */ });
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2156);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4074);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(409);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_0__, swiper__WEBPACK_IMPORTED_MODULE_1__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_0__, swiper__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







swiper__WEBPACK_IMPORTED_MODULE_1__.default.use([swiper__WEBPACK_IMPORTED_MODULE_1__.Scrollbar, swiper__WEBPACK_IMPORTED_MODULE_1__.Autoplay]);
const SwiperTablet = ({
  imagesSwiper
}) => {
  const images = imagesSwiper.map(list => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_0__.SwiperSlide, {
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().swiperSlide),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
      src: list.src,
      alt: list.alt
    })
  }, list.id));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_0__.Swiper, {
    spaceBetween: 30,
    slidesPerView: 2.5,
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().Swiper),
    loop: true,
    autoplay: {
      delay: 2000
    },
    disableOnInteraction: true,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
      children: images
    })
  });
};
});

/***/ }),

/***/ 8178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M2": () => (/* reexport safe */ _SwiperDesktop__WEBPACK_IMPORTED_MODULE_0__.M),
/* harmony export */   "vT": () => (/* reexport safe */ _SwiperTablet__WEBPACK_IMPORTED_MODULE_1__.v),
/* harmony export */   "rw": () => (/* reexport safe */ _SwiperMobile__WEBPACK_IMPORTED_MODULE_2__.r)
/* harmony export */ });
/* harmony import */ var _SwiperDesktop__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2859);
/* harmony import */ var _SwiperTablet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7755);
/* harmony import */ var _SwiperMobile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2682);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SwiperMobile__WEBPACK_IMPORTED_MODULE_2__, _SwiperTablet__WEBPACK_IMPORTED_MODULE_1__, _SwiperDesktop__WEBPACK_IMPORTED_MODULE_0__]);
([_SwiperMobile__WEBPACK_IMPORTED_MODULE_2__, _SwiperTablet__WEBPACK_IMPORTED_MODULE_1__, _SwiperDesktop__WEBPACK_IMPORTED_MODULE_0__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



});

/***/ }),

/***/ 749:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* reexport safe */ _component__WEBPACK_IMPORTED_MODULE_0__.U)
/* harmony export */ });
/* harmony import */ var _component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8157);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component__WEBPACK_IMPORTED_MODULE_0__]);
_component__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 7009:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* reexport safe */ _SwiperUI__WEBPACK_IMPORTED_MODULE_0__.U)
/* harmony export */ });
/* harmony import */ var _SwiperUI__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(749);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SwiperUI__WEBPACK_IMPORTED_MODULE_0__]);
_SwiperUI__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

});

/***/ }),

/***/ 6977:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "style_container__3OvhS",
	"row": "style_row__3ZH_1",
	"column": "style_column__ZgNhr",
	"items": "style_items__gjqLn"
};


/***/ }),

/***/ 7080:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "style_container__2yjWk",
	"wrapper": "style_wrapper__1U_GT",
	"row": "style_row__2s0rj",
	"column": "style_column__2cJkJ",
	"items": "style_items__3rDNS"
};


/***/ }),

/***/ 4699:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "style_section__Iv9F7",
	"container": "style_container__3N-pu",
	"row": "style_row__2OuOi",
	"column": "style_column__1IUs6",
	"button": "style_button__1A1k_",
	"border": "style_border__287yD"
};


/***/ }),

/***/ 4537:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "style_container__3VnEw",
	"wrapper": "style_wrapper__3hio5",
	"row": "style_row__2apws",
	"column": "style_column__2JHiB",
	"items": "style_items__jBBc7"
};


/***/ }),

/***/ 1393:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "style_container__T3IY0",
	"row": "style_row__YyCuU",
	"column": "style_column__2C4dx",
	"Swiper": "style_Swiper__rtOgv"
};


/***/ }),

/***/ 3683:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "style_container__3xsYH",
	"row": "style_row__2cvnl",
	"column": "style_column__2ahXG",
	"items": "style_items__2w7-_",
	"box": "style_box__2_uhx",
	"backgroundBu": "style_backgroundBu__106Ns",
	"link": "style_link__1yNIe"
};


/***/ }),

/***/ 5291:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "style_container__wuDCZ",
	"row": "style_row__UtNBP",
	"column": "style_column__2xAwr",
	"items": "style_items__3Oisi"
};


/***/ }),

/***/ 1904:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "style_wrapper__3Fslb",
	"container": "style_container__3TRJ_",
	"column": "style_column__2BUVd",
	"row": "style_row__1BOT0",
	"items": "style_items__zmWvB",
	"backShinomontaj": "style_backShinomontaj__2fFf7"
};


/***/ }),

/***/ 5254:
/***/ ((module) => {

// Exports
module.exports = {
	"Swiper": "style_Swiper__3X3qD",
	"swiperSlide": "style_swiperSlide__17Ktv"
};


/***/ }),

/***/ 9445:
/***/ ((module) => {

// Exports
module.exports = {
	"Swiper": "style_Swiper__1hSHI",
	"swiperSlide": "style_swiperSlide__3n34q"
};


/***/ }),

/***/ 409:
/***/ ((module) => {

// Exports
module.exports = {
	"Swiper": "style_Swiper__3HdlE",
	"swiperSlide": "style_swiperSlide__XomSq"
};


/***/ })

};
;