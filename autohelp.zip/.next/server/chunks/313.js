exports.id = 313;
exports.ids = [313];
exports.modules = {

/***/ 2488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "rK": () => (/* reexport */ FOOTER_CONSTANT),
  "fb": () => (/* reexport */ FooterContext),
  "VT": () => (/* reexport */ HOME_CONSTANT),
  "Q8": () => (/* reexport */ HomeContext),
  "Ho": () => (/* reexport */ PRICE_CONSTANT),
  "Me": () => (/* reexport */ PriceContext),
  "aj": () => (/* reexport */ WHYOURTIRESERVICE_CONSTANT),
  "y9": () => (/* reexport */ WhyOurTireServiceContext)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/HEADER.js
const HEADER = {
  NAV_LINKS: [{
    id: 1,
    name: 'Почему мы?',
    HREF: '/#whyUs'
  }, {
    id: 2,
    name: 'Услуги',
    HREF: '/#ourServices'
  }, {
    id: 3,
    name: 'Шиномонтаж',
    HREF: '/tireServices'
  }, {
    id: 4,
    name: 'Работы',
    HREF: '/#ourWork'
  }, {
    id: 5,
    name: 'Цены',
    HREF: '/prices'
  }, {
    id: 6,
    name: 'Отзывы',
    HREF: '/reviews'
  }, {
    id: 7,
    name: 'Контакты',
    HREF: '/#contacts'
  }]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/MAIN_SECTION.js
const MAIN_SECTION = {
  CONTENT: [[{
    H1: 'Услуги эвакуации и шиномонтажа'
  }, {
    H2: 'Работаем по Московской и Тульской областям'
  }], [{
    TITLE: 'Качество'
  }, {
    CONTENT: 'Выполняем работу качественно более 20 лет'
  }], [{
    TITLE: 'В любое время'
  }, {
    CONTENT: 'Помогаем круглосуточно и в любую погоду'
  }], [{
    TITLE: 'Разные виды'
  }, {
    CONTENT: 'Грузовой и легковой шиномонтаж'
  }]]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/WHY_US.js
const WHY_US = {
  TITLE: 'Почему мы.',
  CONTENT: [[{
    TITLE: 'Эвакуатор:'
  }, {
    CONTENT: 'Услуга «прикурить» 12в'
  }, {
    CONTENT: 'Сброс ошибок «check engine»'
  }, {
    CONTENT: 'Быстрая подача'
  }, {
    CONTENT: 'Оперативная доставка в автосервис'
  }], [{
    CONTENT: 'Низкая и адекватная стоимость работ при любом способе оплаты.'
  }], [{
    CONTENT: 'Мы работаем в любое время и погоду.'
  }, {
    CONTENT: 'А также предоставляем документы для страховой компании.'
  }], [{
    TITLE: 'Шиномонтаж:'
  }, {
    CONTENT: 'Легковой и грузовой шиномонтаж'
  }, {
    CONTENT: 'Выездной шиномонтаж'
  }, {
    CONTENT: 'Делаем колеса с кольцами'
  }, {
    CONTENT: 'Без очереди клиенту с трассы'
  }]]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/OUR_SERVICES.js
const OUR_SERVICES = {
  TITLE: 'Наши услуги.',
  CONTENT: [[{
    TITLE: 'Мы занимаемся эвакуацией техники разного вида'
  }], [{
    TITLE: 'Автомобили.'
  }, {
    TITLE: 'Тракторы.'
  }, {
    TITLE: 'Катки.'
  }, {
    TITLE: 'Прицепы.'
  }, {
    TITLE: 'Мотоциклы.'
  }, {
    TITLE: 'И другое.'
  }]]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/LOAD_CAPACITY.js
const LOAD_CAPACITY = {
  TITLE: 'Грузоподъёмность.',
  CONTENT: [[{
    CONTENT: 'Грузоподъёмность: до '
  }, {
    CONTENT: '4-х тонн'
  }], [{
    CONTENT: 'Цена за вызов: '
  }, {
    CONTENT: 'от 1500 рублей'
  }], [{
    CONTENT: '*Цены зависят от массы техники, расстояния перевозки, состояния автомобиля'
  }]]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/WHERE_WE_WORK.js
const WHERE_WE_WORK = {
  TITLE: 'Где работаем.',
  CONTENT: [[{
    TITLE: 'Трасса М4 «Дон»'
  }, {
    TITLE: 'Трасса М6 «Каспий»'
  }], [{
    TITLE: 'Московская область'
  }, {
    CONTENT: '-Кашира'
  }, {
    CONTENT: '-Ступино'
  }, {
    CONTENT: '-Михнево'
  }, {
    CONTENT: '-Малино'
  }, {
    CONTENT: '-Ситне-Щелканово'
  }, {
    CONTENT: '-Котлово'
  }, {
    CONTENT: '-Барабаново'
  }], [{
    TITLE: 'Тульская область'
  }, {
    CONTENT: '-Кончинка'
  }, {
    CONTENT: '-Венёв'
  }], [{
    TITLE: 'Московская область'
  }, {
    CONTENT: '-Серебрянные пруды'
  }, {
    CONTENT: '-Кокино'
  }, {
    CONTENT: '-Петрово'
  }, {
    CONTENT: '-Шеметово'
  }, {
    CONTENT: '-Каменка'
  }], [{
    TITLE: 'Тульская область'
  }, {
    CONTENT: '-Козловка'
  }]]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/TIRE_SERVICES.js
const TIRE_SERVICES = {
  TITLE: 'Шиномонтаж.',
  CONTENT: [{
    TITLE: 'Легковой.'
  }, {
    TITLE: 'Грузовой.'
  }, {
    TITLE: 'Выездной.'
  }, {
    TITLE: 'Продажа б/у резины для грузовых авто.'
  }, {
    CONTENT: 'Смотреть подробные цены эвакуации и шиномонтажа'
  }]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/OUR_WORK.js
const OUR_WORK = {
  TITLE: 'Наши работы.'
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/CONTACTS.js
const CONTACTS = {
  TITLE: 'Контакты.',
  CONTENT: [[{
    TEL: '+7 (925) 049 99-62 — '
  }, {
    CONTENT: 'Кашира'
  }], [{
    TEL: '+7 (919) 082 68-95 — '
  }, {
    CONTENT: 'Ступино'
  }], [{
    CONTENT: 'telegram'
  }, {
    CONTENT: 'whatsapp'
  }]]
};
;// CONCATENATED MODULE: ./contexts/HomeContext/constants/index.js









;// CONCATENATED MODULE: ./contexts/HomeContext/context.js


const HOME_CONSTANT = {
  HEADER: HEADER,
  MAIN_SECTION: MAIN_SECTION,
  WHY_US: WHY_US,
  OUR_SERVICES: OUR_SERVICES,
  LOAD_CAPACITY: LOAD_CAPACITY,
  WHERE_WE_WORK: WHERE_WE_WORK,
  TIRE_SERVICES: TIRE_SERVICES,
  OUR_WORK: OUR_WORK,
  CONTACTS: CONTACTS
};
const HomeContext = /*#__PURE__*/(0,external_react_.createContext)();
;// CONCATENATED MODULE: ./contexts/HomeContext/index.js

;// CONCATENATED MODULE: ./contexts/FooterContext/constants/FOOTER.js
const FOOTER = {
  CONTACTS: [{
    TEL: '+7 (925) 049 99-62',
    HREF: 'tel:89250499962'
  }, {
    TEL: '+7 (919) 082 68-95',
    HREF: 'tel:89190826895'
  }, {
    CONTENT: '“Автопомощь.” 2021'
  }],
  MENU: [{
    TITLE: 'Меню.'
  }, {
    NAV_LINKS: [{
      ID: 1,
      NAME: 'Почему мы?',
      HREF: '/#whyUs'
    }, {
      ID: 2,
      NAME: 'Услуги',
      HREF: '/#ourServices'
    }, {
      ID: 3,
      NAME: 'Цены',
      HREF: '/prices'
    }, {
      ID: 4,
      NAME: 'Работы',
      HREF: '/#ourWork'
    }, {
      ID: 5,
      NAME: 'Шиномонтаж',
      HREF: '/tireServices'
    }, {
      ID: 6,
      NAME: 'Отзывы',
      HREF: '/reviews'
    }]
  }],
  DEVELOPMENT: [{
    TITLE: 'Сайт запустили.'
  }, {
    CONTENT: 'Разработка BAURINANTON'
  }, {
    CONTENT: 'Дизайн BAURINARTYOM'
  }]
};
;// CONCATENATED MODULE: ./contexts/FooterContext/constants/index.js

;// CONCATENATED MODULE: ./contexts/FooterContext/context.js


const FOOTER_CONSTANT = {
  FOOTER: FOOTER
};
const FooterContext = /*#__PURE__*/(0,external_react_.createContext)();
;// CONCATENATED MODULE: ./contexts/FooterContext/index.js

;// CONCATENATED MODULE: ./contexts/TireServicesContext/constants/WHYOURTIRESERVICE.js
const WHYOURTIRESERVICE = {
  TITLE: 'Почему наш шиномонтаж.',
  CONTENT: [{
    CONTENT: 'Делаем колеса с кольцами при шиномонтаже'
  }, {
    CONTENT: 'Круглосуточная работа шиномонтажа'
  }, {
    CONTENT: 'Без очереди клиенту с трассы'
  }, {
    CONTENT: 'Низкая, адекватная стоимость'
  }, {
    CONTENT: 'Качественная работа'
  }, {
    CONTENT: 'Вежливые сотрудники'
  }]
};
;// CONCATENATED MODULE: ./contexts/TireServicesContext/constants/index.js

;// CONCATENATED MODULE: ./contexts/TireServicesContext/context.js


const WHYOURTIRESERVICE_CONSTANT = {
  WHYOURTIRESERVICE: WHYOURTIRESERVICE
};
const WhyOurTireServiceContext = /*#__PURE__*/(0,external_react_.createContext)();
;// CONCATENATED MODULE: ./contexts/TireServicesContext/index.js

;// CONCATENATED MODULE: ./contexts/PricesContext/constants/THE_COST_OF_EVACUATION.js
const THE_COST_OF_EVACUATION = {
  TITLE: 'Стоимость эвакуации.',
  CONTENT: [[{
    CONTENT: 'Грузоподъёмность: до '
  }, {
    CONTENT: '4-х тонн'
  }], [{
    CONTENT: 'Цена за вызов: '
  }, {
    CONTENT: 'от 1500 рублей'
  }], [{
    CONTENT: '*Цены зависят от массы техники, расстояния перевозки, состояния автомобиля'
  }]]
};
;// CONCATENATED MODULE: ./contexts/PricesContext/constants/THE_COST_OF_TIRE_REPAIR.js
const THE_COST_OF_TIRE_REPAIR = {
  TITLE: 'Стоимость шиномонтажа.',
  TITLE_MOBILE: [{
    TITLE: 'Стоимость'
  }, {
    TITLE: 'шиномонтажа.'
  }],
  DEPARTURE: [{
    TITLE: 'Выездной шиномонтаж:'
  }, {
    CONTENT: 'Выезд стоит '
  }, {
    CONTENT: '3000 рублей до 20 км'
  }]
};
;// CONCATENATED MODULE: ./contexts/PricesContext/constants/TABLE_ONE.js
const TABLE_ONE = {
  TITLE: [{
    TITLE: 'Автомобильный шиномонтаж: '
  }, {
    TITLE: '"ДЕМОНТАЖ-МОНТАЖ-БАЛАНСИРОВКА"'
  }],
  COLUMN_ONE: [{
    TITLE: 'Радиус'
  }, {
    CONTENT: 'R12',
    id: 1
  }, {
    CONTENT: 'R13',
    id: 2
  }, {
    CONTENT: 'R14',
    id: 3
  }, {
    CONTENT: 'R15',
    id: 4
  }, {
    CONTENT: 'R16',
    id: 5
  }, {
    CONTENT: 'R17',
    id: 6
  }, {
    CONTENT: 'R18',
    id: 7
  }, {
    CONTENT: 'R19',
    id: 8
  }, {
    CONTENT: 'R20',
    id: 9
  }, {
    CONTENT: 'R21',
    id: 10
  }, {
    CONTENT: 'R22',
    id: 1
  }],
  COLUMN_TO: [{
    TITLE: 'Демонтаж'
  }, {
    CONTENT: '110',
    id: 1
  }, {
    CONTENT: '110',
    id: 2
  }, {
    CONTENT: '120',
    id: 3
  }, {
    CONTENT: '130',
    id: 4
  }, {
    CONTENT: '140',
    id: 5
  }, {
    CONTENT: '160',
    id: 6
  }, {
    CONTENT: '170',
    id: 7
  }, {
    CONTENT: '190',
    id: 8
  }, {
    CONTENT: '260',
    id: 9
  }, {
    CONTENT: '260',
    id: 10
  }, {
    CONTENT: '260',
    id: 11
  }],
  COLUMN_THREE: [{
    TITLE: 'Монтаж'
  }, {
    CONTENT: '110',
    id: 1
  }, {
    CONTENT: '110',
    id: 2
  }, {
    CONTENT: '120',
    id: 3
  }, {
    CONTENT: '130',
    id: 4
  }, {
    CONTENT: '140',
    id: 5
  }, {
    CONTENT: '160',
    id: 6
  }, {
    CONTENT: '170',
    id: 7
  }, {
    CONTENT: '190',
    id: 8
  }, {
    CONTENT: '260',
    id: 9
  }, {
    CONTENT: '260',
    id: 10
  }, {
    CONTENT: '260',
    id: 1
  }],
  COLUMN_FOUR: [{
    TITLE: 'Балансировка'
  }, {
    CONTENT: '110',
    id: 1
  }, {
    CONTENT: '110',
    id: 2
  }, {
    CONTENT: '120',
    id: 3
  }, {
    CONTENT: '130',
    id: 4
  }, {
    CONTENT: '140',
    id: 5
  }, {
    CONTENT: '160',
    id: 6
  }, {
    CONTENT: '170',
    id: 7
  }, {
    CONTENT: '190',
    id: 8
  }, {
    CONTENT: '260',
    id: 9
  }, {
    CONTENT: '260',
    id: 10
  }, {
    CONTENT: '260',
    id: 11
  }],
  COLUMN_FIVE: [{
    TITLE: 'за 4 колеса'
  }, {
    CONTENT: '1320',
    id: 1
  }, {
    CONTENT: '1320',
    id: 2
  }, {
    CONTENT: '1440',
    id: 3
  }, {
    CONTENT: '1560',
    id: 4
  }, {
    CONTENT: '1680',
    id: 5
  }, {
    CONTENT: '1920',
    id: 6
  }, {
    CONTENT: '2040',
    id: 7
  }, {
    CONTENT: '2280',
    id: 8
  }, {
    CONTENT: '3120',
    id: 9
  }, {
    CONTENT: '3120',
    id: 10
  }, {
    CONTENT: '3120',
    id: 11
  }]
};
;// CONCATENATED MODULE: ./contexts/PricesContext/constants/TABLE_TO.js
const TABLE_TO = {
  TITLE: [{
    TITLE: 'Автомобильный шиномонтаж'
  }, {
    TITLE: '"ДЕМОНТАЖ-МОНТАЖ-БАЛАНСИРОВКА" '
  }, {
    TITLE: 'Железные диски'
  }],
  COLUMN_ONE: [{
    TITLE: 'Радиус'
  }, {
    CONTENT: 'R12',
    id: 1
  }, {
    CONTENT: 'R13',
    id: 2
  }, {
    CONTENT: 'R14',
    id: 3
  }, {
    CONTENT: 'R15',
    id: 4
  }, {
    CONTENT: 'R16',
    id: 5
  }, {
    CONTENT: 'R17',
    id: 6
  }, {
    CONTENT: 'R18',
    id: 7
  }],
  COLUMN_TO: [{
    TITLE: 'Демонтаж'
  }, {
    CONTENT: '100',
    id: 1
  }, {
    CONTENT: '100',
    id: 2
  }, {
    CONTENT: '110',
    id: 3
  }, {
    CONTENT: '120',
    id: 4
  }, {
    CONTENT: '130',
    id: 5
  }, {
    CONTENT: '150',
    id: 6
  }, {
    CONTENT: '160',
    id: 7
  }],
  COLUMN_THREE: [{
    TITLE: 'Монтаж'
  }, {
    CONTENT: '100',
    id: 1
  }, {
    CONTENT: '100',
    id: 2
  }, {
    CONTENT: '110',
    id: 3
  }, {
    CONTENT: '120',
    id: 4
  }, {
    CONTENT: '130',
    id: 5
  }, {
    CONTENT: '150',
    id: 6
  }, {
    CONTENT: '160',
    id: 7
  }],
  COLUMN_FOUR: [{
    TITLE: 'Балансировка'
  }, {
    CONTENT: '100',
    id: 1
  }, {
    CONTENT: '100',
    id: 2
  }, {
    CONTENT: '110',
    id: 3
  }, {
    CONTENT: '120',
    id: 4
  }, {
    CONTENT: '130',
    id: 5
  }, {
    CONTENT: '150',
    id: 6
  }, {
    CONTENT: '160',
    id: 7
  }],
  COLUMN_FIVE: [{
    TITLE: 'за 4 колеса'
  }, {
    CONTENT: '1200',
    id: 1
  }, {
    CONTENT: '1200',
    id: 2
  }, {
    CONTENT: '1320',
    id: 3
  }, {
    CONTENT: '1440',
    id: 4
  }, {
    CONTENT: '1560',
    id: 5
  }, {
    CONTENT: '1800',
    id: 6
  }, {
    CONTENT: '1920',
    id: 7
  }]
};
;// CONCATENATED MODULE: ./contexts/PricesContext/constants/TABLE_THREE.js
const TABLE_THREE = {
  TITLE: [{
    TITLE: 'Грузовой шиномонтаж'
  }],
  COLUMN_ONE: [{
    TITLE: 'Услуга'
  }, {
    CONTENT: 'Снятие/установка одного колеса',
    id: 1
  }, {
    CONTENT: 'Снятие/установка одного внетреннего колеса (без футурок)',
    id: 2
  }, {
    CONTENT: 'Демонтаж',
    id: 3
  }, {
    CONTENT: 'Монтаж',
    id: 4
  }, {
    CONTENT: 'Монтаж одного колеса с кольцом',
    id: 5
  }, {
    CONTENT: 'Демонтаж одного колеса с кольцом',
    id: 6
  }, {
    CONTENT: 'Балансировка одного колеса без учета грузов',
    id: 7
  }],
  COLUMN_TO: [{
    TITLE: '17.5'
  }, {
    CONTENT: '150',
    id: 1
  }, {
    CONTENT: '200',
    id: 2
  }, {
    CONTENT: '200',
    id: 3
  }, {
    CONTENT: '200',
    id: 4
  }, {
    CONTENT: '300',
    id: 5
  }, {
    CONTENT: '300',
    id: 6
  }, {
    CONTENT: '300',
    id: 7
  }],
  COLUMN_THREE: [{
    TITLE: '19.5-22.5'
  }, {
    CONTENT: '300',
    id: 1
  }, {
    CONTENT: '350',
    id: 2
  }, {
    CONTENT: '300',
    id: 3
  }, {
    CONTENT: '300',
    id: 4
  }, {
    CONTENT: '400',
    id: 5
  }, {
    CONTENT: '400',
    id: 6
  }, {
    CONTENT: '300',
    id: 7
  }],
  COLUMN_FOUR: [{
    TITLE: '24 и выше'
  }, {
    CONTENT: '350',
    id: 1
  }, {
    CONTENT: '400',
    id: 2
  }, {
    CONTENT: '300',
    id: 3
  }, {
    CONTENT: '300',
    id: 4
  }, {
    CONTENT: '400',
    id: 5
  }, {
    CONTENT: '400',
    id: 6
  }, {
    CONTENT: '-',
    id: 7
  }]
};
;// CONCATENATED MODULE: ./contexts/PricesContext/constants/TABLE_FOUR.js
const TABLE_FOUR = {
  TITLE: [{
    title: 'Грузовой шиномонтаж'
  }],
  COLUMN_ONE: [{
    title: 'Наименование'
  }, {
    content: 'Демонтаж 1 сторона'
  }, {
    content: 'Монтаж 1 сторона'
  }, {
    content: 'Снятие, установка'
  }, {
    content: 'Установка камеры'
  }, {
    content: 'Ремонт покрышки'
  }, {
    content: 'Ремонт камер'
  }],
  COLUMN_TO: [{
    title: 'Цена'
  }, {
    content: '350'
  }, {
    content: '350'
  }, {
    content: '400'
  }, {
    content: '200'
  }, {
    content: '450, без материала'
  }, {
    content: '250'
  }]
};
;// CONCATENATED MODULE: ./contexts/PricesContext/constants/index.js






;// CONCATENATED MODULE: ./contexts/PricesContext/context.js


const PRICE_CONSTANT = {
  THE_COST_OF_EVACUATION: THE_COST_OF_EVACUATION,
  THE_COST_OF_TIRE_REPAIR: THE_COST_OF_TIRE_REPAIR,
  TABLE_ONE: TABLE_ONE,
  TABLE_TO: TABLE_TO,
  TABLE_THREE: TABLE_THREE,
  TABLE_FOUR: TABLE_FOUR
};
const PriceContext = /*#__PURE__*/(0,external_react_.createContext)();
;// CONCATENATED MODULE: ./contexts/PricesContext/index.js

;// CONCATENATED MODULE: ./contexts/index.js





/***/ }),

/***/ 4589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "v": () => (/* reexport */ useScroll),
  "i": () => (/* reexport */ useWindowSize)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./hook/useWindowSize.js

const useWindowSize = () => {
  const {
    0: windowSize,
    1: setWindowSize
  } = (0,external_react_.useState)({
    width: undefined
  });
  (0,external_react_.useEffect)(() => {
    const handleWindowSize = () => setWindowSize({
      width: window.innerWidth
    });

    handleWindowSize();
    window.addEventListener("resize", handleWindowSize);
    return () => window.removeEventListener("resize", handleWindowSize);
  }, []);
  return windowSize;
};
;// CONCATENATED MODULE: ./hook/useScroll.js

const useScroll = () => {
  const {
    0: windowScroll,
    1: setWindowScroll
  } = (0,external_react_.useState)({
    height: undefined
  });
  (0,external_react_.useEffect)(() => {
    const handleWindowScroll = () => setWindowScroll({
      height: window.scrollY
    });

    handleWindowScroll();
    window.addEventListener("scroll", handleWindowScroll);
    return () => window.removeEventListener("scroll", handleWindowScroll);
  }, []);
  return windowScroll;
};
;// CONCATENATED MODULE: ./hook/index.js



/***/ }),

/***/ 87:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "$": () => (/* reexport */ Footer)
});

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/footer/style.module.scss
var style_module = __webpack_require__(8530);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/footer/layout.jsx






const Footer = () => {
  const {
    FOOTER: {
      CONTACTS,
      MENU,
      DEVELOPMENT
    }
  } = (0,external_react_.useContext)(contexts/* FooterContext */.fb);
  const navLink = MENU[1].NAV_LINKS.map(list => /*#__PURE__*/jsx_runtime_.jsx("li", {
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: list.HREF,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        children: list.NAME
      })
    })
  }, list.ID));
  return /*#__PURE__*/jsx_runtime_.jsx("footer", {
    className: (style_module_default()).footer,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).container,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).column,
        children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
          src: "/img/Footer/logo.svg",
          alt: "logo"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).items,
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: CONTACTS[0].HREF,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: CONTACTS[0].TEL
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: CONTACTS[1].HREF,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: CONTACTS[1].TEL
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h4", {
          children: ["\xA9", CONTACTS[2].CONTENT]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).column,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          children: MENU[0].TITLE
        }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
          children: navLink
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).column,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          children: DEVELOPMENT[0].TITLE
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).items,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: DEVELOPMENT[1].CONTENT
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).box,
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "https://t.me/baurinanton",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/img/Footer/telegram.svg",
                  alt: "telegram"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "https://instagram.com/baurin.anton",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/img/Footer/instagram.svg",
                  alt: "instagram"
                })
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (style_module_default()).items,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: DEVELOPMENT[2].CONTENT
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).box,
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "https://www.behance.net/artemartemartem",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/img/Footer/be.svg",
                  alt: "behance"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "https://t.me/artembaurin",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/img/Footer/telegram.svg",
                  alt: "telegram"
                })
              })
            })]
          })]
        })]
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/footer/index.js


/***/ }),

/***/ 480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* reexport */ Header)
});

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./contexts/index.js + 29 modules
var contexts = __webpack_require__(2488);
// EXTERNAL MODULE: ./modules/header/layouts/HeaderFixed/style.module.scss
var style_module = __webpack_require__(417);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderFixed/layout.jsx






const HeaderFixed = () => {
  const {
    HEADER: {
      NAV_LINKS
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  const navText = NAV_LINKS.map(nav => /*#__PURE__*/jsx_runtime_.jsx("li", {
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: nav.HREF,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: (style_module_default()).link,
        children: nav.name
      })
    })
  }, nav.id));
  return /*#__PURE__*/jsx_runtime_.jsx("header", {
    className: (style_module_default()).header,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (style_module_default()).wrapper,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (style_module_default()).column,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/Header/logoFixed.svg",
              alt: "logo"
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (style_module_default()).column,
        children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
          children: navText
        })
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderFixed/index.js

// EXTERNAL MODULE: ./modules/header/layouts/HeaderMain/style.module.scss
var HeaderMain_style_module = __webpack_require__(1463);
var HeaderMain_style_module_default = /*#__PURE__*/__webpack_require__.n(HeaderMain_style_module);
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMain/layout.jsx






const HeaderMain = () => {
  const {
    HEADER: {
      NAV_LINKS
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  const navText = NAV_LINKS.map(nav => /*#__PURE__*/jsx_runtime_.jsx("li", {
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: nav.HREF,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: (HeaderMain_style_module_default()).link,
        children: nav.name
      })
    })
  }, nav.id));
  return /*#__PURE__*/jsx_runtime_.jsx("header", {
    className: (HeaderMain_style_module_default()).header,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (HeaderMain_style_module_default()).wrapper,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (HeaderMain_style_module_default()).column,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/Header/logo.svg",
              alt: "logo"
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (HeaderMain_style_module_default()).column,
        children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
          children: navText
        })
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMain/index.js

// EXTERNAL MODULE: ./modules/header/layouts/HeaderTablet/style.module.scss
var HeaderTablet_style_module = __webpack_require__(6227);
var HeaderTablet_style_module_default = /*#__PURE__*/__webpack_require__.n(HeaderTablet_style_module);
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderTablet/layout.jsx






const HeaderTablet = () => {
  const {
    HEADER: {
      NAV_LINKS
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  const navText = NAV_LINKS.map(nav => /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (HeaderTablet_style_module_default()).column,
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: nav.HREF,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
          src: `img/Header/HeaderTablet/image_${nav.id}.svg`,
          alt: "img"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          children: nav.name
        })]
      })
    })
  }, nav.id));
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (HeaderTablet_style_module_default()).headerWrapper,
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (HeaderTablet_style_module_default()).container,
      children: navText
    })
  });
};
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderTablet/index.js

// EXTERNAL MODULE: ./modules/header/layouts/HeaderMobile/layouts/ButtonMenu/style.module.scss
var ButtonMenu_style_module = __webpack_require__(6781);
var ButtonMenu_style_module_default = /*#__PURE__*/__webpack_require__.n(ButtonMenu_style_module);
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMobile/layouts/ButtonMenu/layout.jsx



const ButtonMenu = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (ButtonMenu_style_module_default()).menu,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (ButtonMenu_style_module_default()).burger,
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        className: (ButtonMenu_style_module_default()).line
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: (ButtonMenu_style_module_default()).line
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: (ButtonMenu_style_module_default()).line
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: (ButtonMenu_style_module_default()).text,
      children: 'Меню'
    })]
  });
};
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMobile/layouts/ButtonMenu/index.js

;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMobile/layouts/index.js

// EXTERNAL MODULE: ./modules/header/layouts/HeaderMobile/style.module.scss
var HeaderMobile_style_module = __webpack_require__(5152);
var HeaderMobile_style_module_default = /*#__PURE__*/__webpack_require__.n(HeaderMobile_style_module);
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMobile/layout.jsx







const HeaderMobile = () => {
  const {
    HEADER: {
      NAV_LINKS
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  const {
    0: state,
    1: setState
  } = (0,external_react_.useState)(false);
  const navText = NAV_LINKS.map(nav => /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (HeaderMobile_style_module_default()).column,
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: nav.HREF,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        onClick: () => setState(!state),
        children: nav.name
      })
    })
  }, nav.id));
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (HeaderMobile_style_module_default()).headerMobile,
    children: [state ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (HeaderMobile_style_module_default()).contentMenu,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (HeaderMobile_style_module_default()).row,
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            onClick: () => setState(!state),
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/Header/logoFixed.svg",
              alt: "logo"
            })
          })
        }), navText]
      })
    }) : '', /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (HeaderMobile_style_module_default()).container,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (HeaderMobile_style_module_default()).row,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (HeaderMobile_style_module_default()).column,
          onClick: () => setState(!state),
          children: /*#__PURE__*/jsx_runtime_.jsx(ButtonMenu, {})
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (HeaderMobile_style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: NAV_LINKS[1].HREF,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/Header/HeaderTablet/image_2.svg",
                className: (HeaderMobile_style_module_default()).imgOne,
                alt: "img"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: NAV_LINKS[1].name
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (HeaderMobile_style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: NAV_LINKS[4].HREF,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/Header/HeaderTablet/image_5.svg",
                className: (HeaderMobile_style_module_default()).imgTo,
                alt: "img"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: NAV_LINKS[4].name
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (HeaderMobile_style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: NAV_LINKS[2].HREF,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/Header/HeaderTablet/image_3.svg",
                className: (HeaderMobile_style_module_default()).imgThree,
                alt: "img"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: NAV_LINKS[2].name
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (HeaderMobile_style_module_default()).column,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: NAV_LINKS[6].HREF,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "img/Header/HeaderTablet/image_7.svg",
                className: (HeaderMobile_style_module_default()).imgFour,
                alt: "img"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: NAV_LINKS[6].name
              })]
            })
          })
        })]
      })
    })]
  });
};
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderMobile/index.js

// EXTERNAL MODULE: ./modules/header/layouts/HeaderPages/style.module.scss
var HeaderPages_style_module = __webpack_require__(4792);
var HeaderPages_style_module_default = /*#__PURE__*/__webpack_require__.n(HeaderPages_style_module);
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderPages/layout.jsx






const HeaderPages = () => {
  const {
    HEADER: {
      NAV_LINKS
    }
  } = (0,external_react_.useContext)(contexts/* HomeContext */.Q8);
  const navText = NAV_LINKS.map(nav => /*#__PURE__*/jsx_runtime_.jsx("li", {
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: nav.HREF,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: (HeaderPages_style_module_default()).link,
        children: nav.name
      })
    })
  }, nav.id));
  return /*#__PURE__*/jsx_runtime_.jsx("header", {
    className: (HeaderPages_style_module_default()).header,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (HeaderPages_style_module_default()).wrapper,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (HeaderPages_style_module_default()).column,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/img/Header/logoFixed.svg",
              alt: "logo"
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (HeaderPages_style_module_default()).column,
        children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
          children: navText
        })
      })]
    })
  });
};
;// CONCATENATED MODULE: ./modules/header/layouts/HeaderPages/index.js

;// CONCATENATED MODULE: ./modules/header/layouts/index.js





// EXTERNAL MODULE: ./hook/index.js + 2 modules
var hook = __webpack_require__(4589);
;// CONCATENATED MODULE: ./modules/header/layout.jsx





const Header = ({
  headerOtherPage
}) => {
  const positionScroll = (0,hook/* useScroll */.v)();
  const windowSize = (0,hook/* useWindowSize */.i)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [headerOtherPage ? /*#__PURE__*/jsx_runtime_.jsx(HeaderPages, {}) : !headerOtherPage ? /*#__PURE__*/jsx_runtime_.jsx(HeaderMain, {}) : '', positionScroll.height > 200 && windowSize.width > 992 ? /*#__PURE__*/jsx_runtime_.jsx(HeaderFixed, {}) : windowSize.width > 577 && windowSize.width <= 992 ? /*#__PURE__*/jsx_runtime_.jsx(HeaderTablet, {}) : windowSize.width <= 576 ? /*#__PURE__*/jsx_runtime_.jsx(HeaderMobile, {}) : '']
  });
};
;// CONCATENATED MODULE: ./modules/header/index.js


/***/ }),

/***/ 8530:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "style_footer__23LlL",
	"container": "style_container__2uij6",
	"column": "style_column__d7Nz5",
	"items": "style_items__2qQ6u",
	"box": "style_box__2eIDG"
};


/***/ }),

/***/ 417:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "style_header__3dncd",
	"wrapper": "style_wrapper__2HShv",
	"column": "style_column__3kfT9",
	"link": "style_link__3j6cM"
};


/***/ }),

/***/ 1463:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "style_header__mBOZj",
	"wrapper": "style_wrapper__h6j0d",
	"column": "style_column__HLi8g",
	"link": "style_link__S9HCV"
};


/***/ }),

/***/ 6781:
/***/ ((module) => {

// Exports
module.exports = {
	"menu": "style_menu__2YXso",
	"burger": "style_burger__1GVY3",
	"line": "style_line__2xI3_",
	"text": "style_text__VITf9"
};


/***/ }),

/***/ 5152:
/***/ ((module) => {

// Exports
module.exports = {
	"headerMobile": "style_headerMobile__sf2ew",
	"container": "style_container__1Z5gO",
	"row": "style_row__2gZub",
	"column": "style_column__21Ejr",
	"imgOne": "style_imgOne__3LRau",
	"imgTo": "style_imgTo__lhxx9",
	"imgThree": "style_imgThree__MSQ5Q",
	"imgFour": "style_imgFour__bNDxi",
	"contentMenu": "style_contentMenu__1sQOV"
};


/***/ }),

/***/ 4792:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "style_header__1Gk0Y",
	"wrapper": "style_wrapper__1q6tO",
	"column": "style_column__3yV4y",
	"link": "style_link__3hU5L"
};


/***/ }),

/***/ 6227:
/***/ ((module) => {

// Exports
module.exports = {
	"headerWrapper": "style_headerWrapper__1EPnH",
	"container": "style_container__1epwF",
	"column": "style_column__1qDyK"
};


/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;